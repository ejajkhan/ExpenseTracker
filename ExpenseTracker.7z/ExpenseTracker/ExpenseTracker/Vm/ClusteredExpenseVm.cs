﻿using ExpenseTracker.Models;

namespace ExpenseTracker.Vm
{
    public class ClusteredExpenseVm
    {
        public decimal Amount { get; set; }
        public Category Category { get; set; }
    }
}
