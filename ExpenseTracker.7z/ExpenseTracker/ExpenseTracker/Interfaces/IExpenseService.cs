﻿using ExpenseTracker.Models;

namespace ExpenseTracker.Interfaces
{
    public interface IExpenseService:IBaseService<Expense>
    {
    }
}
