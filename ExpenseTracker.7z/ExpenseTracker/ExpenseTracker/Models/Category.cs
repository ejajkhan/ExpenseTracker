﻿namespace ExpenseTracker.Models
{
    public class Category : Auditable
    {
        public string Name { get; set; }
    }
}
